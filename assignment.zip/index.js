function setupToggle(buttonId, rangeSelectors = []) {
    const button = document.getElementById(buttonId);
    const ranges = rangeSelectors.map((selector) => document.getElementById(selector));

    button.addEventListener('click', function () {
        if (button.textContent === "ON") {
            button.textContent = "OFF";
            button.classList.add('off');
            
            ranges.forEach((range) => range.disabled = true);
        } else {
            button.textContent = "ON";
            button.classList.remove('off');
        
            ranges.forEach((range) => range.disabled = false);
        }
    });
    if (button.textContent === "OFF") {
        ranges.forEach((range) => range.disabled = true);
    }
}
setupToggle('ac', ['ac-temp']);
setupToggle('fan', ['fan-speed']);
setupToggle('light', ['light-brightness', 'light-color']);
setupToggle('tv', ['tv-volume', 'tv-channel']);
